// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("tcc build"); }
int main(){
  announce();
  return lionss_run_workload("tcc-build");
}
