// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("lldb smoke\n", stdout);
  return lionss_run_workload("lldb-smoke");
}
