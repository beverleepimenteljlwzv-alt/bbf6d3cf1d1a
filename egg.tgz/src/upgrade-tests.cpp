// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("upgrade tests"); }
int main(){
  announce();
  return lionss_run_workload("upgrade-tests");
}
